How to compile programme.

Install Yarn JavaScript (package manager) and run the project in the Visual Studio Code.

Install Yarn:

Step 1: nvm install 10.13.0
Step 2: yarn install
Step 3: yarn start
Step 4: yarn build