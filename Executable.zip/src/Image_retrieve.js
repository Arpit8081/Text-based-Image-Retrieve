// below line imports search result from the given path.
import OnSearch from "./js/Search.js";
// installs all the css functions from the main.css file.
import css from "./css/main.css";